(function (global) {
    'use strict';
    var angular = global.angular;
    angular.module('catalog', ['checklist-model']);
}(window));


