'use strict';
(function (global) {
    var angular = global.angular;
    angular.module('PDFDownload', ['catalog']);
}(window));

