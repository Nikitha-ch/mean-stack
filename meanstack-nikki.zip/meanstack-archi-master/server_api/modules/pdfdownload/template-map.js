'use strict';
module.exports = {
    CATALOG_DOWLOAD: __dirname + '/templates/catalog-list.ejs.html'
};


